export * from './checkInputValidity';
export * from './clearInput';
export * from './formatInput';
export * from './getInputValue';
export * from './handleEnterInInputs';
export * from './setError';
export * from './syncSlider';
