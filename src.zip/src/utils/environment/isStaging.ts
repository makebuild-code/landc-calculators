export const isStaging = !window.location.host.includes('www.landc.co.uk');
