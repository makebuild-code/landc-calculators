import type { Endpoints, Environment } from 'src/types';
import { getEnvironment } from './getEnvironment';

export const getBaseURLForAPI = (): string => {
  const ENDPOINTS: Endpoints = {
    prod: 'https://www.landc.co.uk/api/',
    test: 'https://test.landc.co.uk/api/',
  };

  // If window is not defined (Node.js/SSR), default to test
  if (typeof window === 'undefined') return ENDPOINTS.test;

  const environment = getEnvironment();

  const { search } = window.location;
  const params = new URLSearchParams(search);
  const apiParam = params.get('api');

  if (apiParam) return ENDPOINTS[apiParam as keyof Endpoints] || ENDPOINTS.prod;
  return environment.api;
};
