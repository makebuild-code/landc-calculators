import { details } from './details';
import { dialogs } from './dialogs';

export const components = () => {
  console.log('components');
  dialogs();
  details();
};
