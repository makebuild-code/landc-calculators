import { MCTManager } from 'src/mct/shared/MCTManager';

export const mct = () => {
  MCTManager.start();
};
