import { queryElement, queryElements } from "$utils/dom"
import { mortgageAppointmentSlotsAPI } from "$mct/api"
import type { CreateLeadAndBookingRequest, EnquiryData } from "$mct/types"
import { createLeadAndBookingAPI } from "$mct/api"
import { lcidAPI } from '$mct/api';
import { debugError, debugLog } from "$utils/debug"
import { APIError } from "$mct/api"
import type { Booking, EnquiryForm } from "$mct/types"
import { StateManager } from "$mct/state"
import { formatDateForAPI, fmtTime, makeDateBtn } from "./utils/dates";

let DOM_CONFIG = {
  elements: {
    wrap: 'wrap',
    logo: 'partner-logo',
    product: 'product-info',
    dateBlock: 'date',
    dateList: 'date-list',
    timeBlock: 'time',
    timeList: 'time-list',
    formBlock: 'information',
    form: 'form',
    next: 'next',
    prev: 'back',
    submit: 'submit'
  }
}

const stateManager = new StateManager()

export class partnerBookingWidget {
  bookingData: {
    bookingDate: string,
    bookingStart: string,
    bookingEnd: string
  };

  formData: any

  constructor() {
    this.formData = {}
    this.bookingData = {
      bookingDate: '',
      bookingStart: '',
      bookingEnd: ''
    }
    this.initState();
    this.initICID();
    this.initLCID();
    this.getDates()
    this.setupNavButtons()
    this.notesEventListener()
  }

  initState() {
    // Subscribe to state changes for debugging
    stateManager.subscribe((event) => {
      debugLog('🔄 State changed via new manager:', {
        changes: event.changes,
        timestamp: new Date().toISOString(),
      });
    });
    stateManager.loadFromPersistence();
    stateManager.enableAutoPersistence();
    this.stripUrl()
    console.log(stateManager.getState());
  }

  stripUrl() {
    const params = new Proxy(new URLSearchParams(window.location.search), {
      get(target, prop, receiver) {
        if (typeof prop !== "string" || prop in target) {
          const v = Reflect.get(target, prop, receiver);
          return typeof v === "function" ? v.bind(target) : v;
        }
        return target.get(prop);
      }
    });

    for (const [name, value] of params) {
      this.formData[name] = value
      console.log(this.formData);
    }
  }

  async getDateSlots() {
    const now = new Date()
    const from = new Date(now)
    from.setDate(from.getDate() + 1)
    const to = new Date(from)
    to.setDate(to.getDate() + 14)
    const fromDate = formatDateForAPI(from)
    const toDate = formatDateForAPI(to)
    const response = await mortgageAppointmentSlotsAPI.getSlots(fromDate, toDate);
    return response
  }

  setTimeSlots(day: { slots: { startTime: string; endTime: string; enabled: boolean; capacity?: number }[] }) {
    const list = queryElement(`[data-partner-element="${DOM_CONFIG.elements.timeList}"]`)
    if (!list) return
    const tpl = list.querySelector('.mct_pill_field') as HTMLElement
    const base = tpl.cloneNode(true) as HTMLElement
    list.innerHTML = ''
    for (const s of day.slots ?? []) {
      const el = base.cloneNode(true) as HTMLElement
      const input = el.querySelector('.mct_pill_input') as HTMLInputElement
      const label = el.querySelector('.mct_pill_label') as HTMLLabelElement
      const txt = `${fmtTime(s.startTime)} - ${fmtTime(s.endTime)}`
      label.textContent = txt
      input.value = txt
      input.disabled = !s.enabled || (typeof s.capacity === 'number' && s.capacity <= 0)
      list.appendChild(el)
      el.addEventListener('click', () => {
        this.bookingData = {
          ...this.bookingData,
          bookingStart: s.startTime,
          bookingEnd: s.endTime
        }

        stateManager.set('booking', {
          ...this.bookingData,
          source: 'SYSTEM',
          bookingProfile: 'DEFAULT',
          bookingProfileId: 1,
        });
        console.log(this.bookingData);
        console.log(stateManager.getState());
      })
    }
  }

  async getDates() {
    const data = await this.getDateSlots()
    const list = queryElement(`[data-partner-element="${DOM_CONFIG.elements.dateList}"]`)
    const tpl = queryElement('.mct_pill_field.is-date') as HTMLElement
    if (!list) return
    list.innerHTML = ''
    for (const day of data.result ?? []) {
      const btn = makeDateBtn(day, tpl)
      btn.addEventListener('click', () => {
        const input = btn.querySelector('.mct_pill_input') as HTMLInputElement
        input.checked = true
        this.setTimeSlots(day)
        this.bookingData = {
          ...this.bookingData,
          bookingDate: day.date
        }
        console.log(this.bookingData);

      })
      list.appendChild(btn)
    }
  }

  setupNavButtons() {
    let nextButtons = queryElements(`[data-partner-element="${DOM_CONFIG.elements.next}"]`)
    let prevButtons = queryElements(`[data-partner-element="${DOM_CONFIG.elements.prev}"]`)

    nextButtons.forEach((e) => {
      e.addEventListener('click', () => {
        this.navigateNext(e)
      })
    })

    prevButtons.forEach((e) => {
      e.addEventListener('click', () => {
        this.navigatePrev(e)
      })
    })
  }

  navigateNext(el: HTMLElement | SVGElement) {
    let parent = el.closest('.p-a_block_wrap')
    if (!parent) return

    if (queryElement(':checked', parent)) {
      parent.setAttribute('data-mct-initial', 'none')
      parent.nextElementSibling?.removeAttribute('data-mct-initial')
    } else { alert("Please pick a date & time"); }
  }

  navigatePrev(el: HTMLElement | SVGElement) {
    let parent = el.closest('.p-a_block_wrap')
    if (!parent) return
    parent.setAttribute('data-mct-initial', 'none')
    parent.previousElementSibling?.removeAttribute('data-mct-initial')
  }

  notesEventListener() {
    let yesButton = queryElement('.mct_pill_field:has([name="Notes"]):has([value="Yes"])')
    let noButton = queryElement('.mct_pill_field:has([name="Notes"]):has([value="No"])')
    let block = queryElement('[data-partner-element="notes"]')

    if (!block) {
      console.error('no notes block')
      return
    }
    block.style.display = 'none'

    yesButton?.addEventListener('click', () => {
      block.style.display = 'block'
    })
    noButton?.addEventListener('click', () => {
      block.style.display = 'none'
    })
  }

  async handleFormSubmission(): Promise<void> {
    // Get form data

    if (!stateManager.getState().booking) {
      console.error('form data error');
      return;
    }

    // Create the API request with default values for required fields
    const request: CreateLeadAndBookingRequest = {
      enquiry: {
        ...stateManager.getState().form as EnquiryForm,
        ...stateManager.getState()
      },
      booking: { ...stateManager.getState().booking },
    };

    try {
      // Call the API
      const response = await createLeadAndBookingAPI.createLeadAndBooking(request);

      let form = queryElement('[data-partner-element="information"]')
      let success = queryElement('[data-partner-element="success"]')
      if (!form || !success) return
      // Handle successful booking
      form.style.display = 'none';
      success.style.removeProperty('display');
    } catch (error: unknown) {
      debugError('Error submitting booking:', error);

      // Handle specific API errors
      if (error instanceof APIError) {
        debugError('API Error Status:', error.status);
        debugError('API Error Message:', error.message);

        if (error.status === 409) {
          debugError('Booking error: 409 - Slot already taken');
        } else if (error.status === 400) {
          debugError('Booking error: 400 - Bad request, try again');
        } else {
          debugError('Booking failed with status:', error.status);
          alert('An error occurred while booking your appointment. Please try again.');
        }
      } else {
        // Handle other types of errors
        debugError('Unexpected error:', error);
        alert('An unexpected error occurred. Please try again.');
      }
    }
  }

  initICID() {
    const icid = this.getICID();
    const newICID = !icid || icid === 'default' ? 'mct' : icid;
    this.setICID(newICID);
  }

  async initLCID() {
    const currentLCID = this.getLCID();
    const icid = this.getICID();

    try {
      const lcid = await lcidAPI.generate(currentLCID, icid);
      this.setLCID(lcid);
    } catch {
      debugError('Failed to generate LCID');
    }
  }

  setICID(icid: string) {
    stateManager.setICID(icid);
  }

  getICID(): string | null {
    return stateManager.getICID();
  }

  setLCID(lcid: string | null) {
    stateManager.setLCID(lcid);
  }

  getLCID(): string | null {
    return stateManager.getLCID();
  }

}
